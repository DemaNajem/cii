<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>تسجيل دخول</title>
	
    
    <link rel="stylesheet" href="http://localhost/CI/assets/css/bootstrap.css">
    <script src="http://localhost/CI/assets/js/bootstrap.js"></script>
    <script src="http://localhost/CI/assets/js/jquery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<h1 class="page-header text-center"></h1>
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<div class="login-panel panel panel-primary">
		        <div class="panel-heading">
		            <h3 class="panel-title"  style="    text-align: center;
    margin-top: 17%;"><span class="glyphicon glyphicon-lock"></span> تسجيل دخول
		            </h3>
		        </div>
		    	<div class="panel-body">
		        	<!-- <form method="POST" action="<?php echo base_url(); ?>index.php/user/login">
		            	<fieldset>
		                	<div class="form-group">
		                   	<input class="form-control" placeholder="الرقم الوظيفي" type="text" name="username" required>
                              <?php  $this->form_validation->set_rules('username','Username','trim|required|min_length[3]|max_length[12]'); ?>
		                	</div>
		                	<div class="form-group">
		                    	<input class="form-control"  autocomplete="off" placeholder="كلمة المرور" type="password" name="password" required>
                               
                            </div>
		                	<button type="submit" class="btn btn-lg btn-primary btn-block"><span class="glyphicon glyphicon-log-in"></span> Login</button>
		            	</fieldset>
		        	</form> -->
					<?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
<?php endif; ?>

<form method="POST" action="http://localhost/CI/application/controllers/user/login">
    <fieldset>
        <div class="form-group">
            <input class="form-control" placeholder="الرقم الوظيفي" type="text" name="username" required>
        </div>
        <div class="form-group">
            <input class="form-control" autocomplete="off" placeholder="كلمة المرور" type="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-lg btn-primary btn-block">
            <span class="glyphicon glyphicon-log-in"></span> Login
        </button>
    </fieldset>
</form>

		    	</div>
		    </div>
            <?php
				if($this->session->flashdata('error')){
					?>
					<div class="alert alert-danger text-center" style="margin-top:20px;">
						<?php echo $this->session->flashdata('error'); ?>
					</div>
					<?php
				}
			?>
		</div>
	</div>
</div>

</body>
</html>