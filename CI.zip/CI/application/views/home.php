<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.css">
    <script src="<?php echo base_url()?>assets/js/bootstrap.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.js"></script>
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css2/bootstrap.css">
    <script src="<?php echo base_url()?>assets/js2/bootstrap.js"></script>
    <script src="<?php echo base_url()?>assets/js2/jquery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
	<h1 class="page-header text-center" style="    text-align: center;
    margin-top: 17%;">دخول</h1>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<?php
				$user = $this->session->userdata('user');
				extract($user);
			?>
			<h2>Welcome to Homepage </h2>
		
			<a href="<?php echo base_url(); ?>index.php/user/logout" class="btn btn-danger">تسجيل الخروج</a>
		</div>
	</div>
</div>
</body>
</html>