<?php
	class Users_model extends CI_Model{
function __construct(){
    parent::__construct();
}

public function checkUser($data)
{
    $st=$this->db->SELECT('*')->from('user')
                    ->WHERE('USERNAME ',$data['USERNAME '])
                    ->WHERE('password',(($data['password'])))
                    ->get()->result_array();
    if(count($st)>0)
    {
        return $st[0];
    }
    else
    {
        return false;
    }
}
public function checkPassword($str)
{
    $st=$this->db->SELECT('*')->from('user')
        ->WHERE('username',$this->session->userdata['USERNAME'])
        ->WHERE('password ',(($str)))
        ->get()->result_array();
    if(count($st)>0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

public function updatePassword($PASSWORD ,$USERNAME)
{
    $pass=array(
        'password' => ($PASSWORD )
    );
    $this->db->WHERE('USERNAME ',$USERNAME)->update('username',$pass);
}

}
?>