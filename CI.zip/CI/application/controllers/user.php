<?php
// defined('BASEPATH') OR exit('No direct script access allowed');
 
// class User extends CI_Controller {
 
// 	function __construct(){
// 		parent::__construct();
// 		$this->load->helper('url');
// 		$this->load->model('Users_model');
// 	}
 
// 	public function index(){
// 		//load session library
// 		$this->load->library('session');
 
// 		//restrict users to go back to login if session has been set
// 		if($this->session->userdata('user')){
// 			redirect('home');
// 		}
// 		else{
// 			$this->load->view('login_page');
// 		}
// 	}
//     public function login(){
// 		//load session library
// 		$this->load->library('session');
//         $this->load->library('form_validation');

// 		$username = $_POST['username'];
// 		$password = $_POST['password'];
        
//         $this->form_validation->set_rules('username', 'Username', 'required|min_length[5]|max_length[12]');
//         $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
      
//         if ($this->form_validation->run() == FALSE) {
//             // Validation failed, load your form view with validation errors
// 			$this->session->set_flashdata('error','الرقم الوظيفي او كلمة المرور غير صحيحة');
//             $this->load->view('login');
//         } else {
//             // Validation succeeded, process the form data
          
// 			$data = $this->login_model->login($username, $password);
// 			if($data){
// 				$this->session->set_userdata('user', $data);
// 				redirect('home');
            
           
//         }
        
        
		

// 		}
	
// 		} 
	
 
// 	public function home(){
// 		//load session library
// 		$this->load->library('session');
 
// 		//restrict users to go to home if not logged in
// 		if($this->session->userdata('user')){
// 			$this->load->view('home');
// 		}
// 		else{
// 			redirect('/');
// 		}
 
// 	}
//     public function logout(){
// 		//load session library
// 		$this->load->library('session');
// 		$this->session->unset_userdata('user');
// 		redirect('login');
// 	}
 

// }

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Users_model');
    }

    public function index(){
        $this->load->library('session');
        if($this->session->userdata('user')){
            redirect('home');
        } else {
            $this->load->view('login_page');
        }
    }

    public function login(){
        $this->load->library('session');
        $this->load->library('form_validation');

        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[5]|max_length[12]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', 'الرقم الوظيفي او كلمة المرور غير صحيحة');
            $this->load->view('login_page');  // Ensure this points to your login view
        } else {
            $data = $this->Users_model->checkUser(array('USERNAME' => $username, 'password' => $password));
            if($data){
                $this->session->set_userdata('user', $data);
                redirect('home');
            } else {
                $this->session->set_flashdata('error', 'الرقم الوظيفي او كلمة المرور غير صحيحة');
                $this->load->view('login_page');  // Ensure this points to your login view
            }
        }
    }

    public function home(){
        $this->load->library('session');
        if($this->session->userdata('user')){
            $this->load->view('home');
        } else {
            redirect('/');
        }
    }

    public function logout(){
        $this->load->library('session');
        $this->session->unset_userdata('user');
        redirect('login');
    }
}
?>
